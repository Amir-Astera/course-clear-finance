package com.dev.course.feature.modules.presentation.dto

import com.dev.course.feature.lesson.domain.models.Lesson

data class UpdateModuleWithLessonDto(
        val id: String,
        val lessons: Collection<String>
)
