package com.dev.course.feature.repositories

import com.dev.course.feature.files.data.LessonFilesEntity
import kotlinx.coroutines.flow.Flow
import org.springframework.data.repository.kotlin.CoroutineCrudRepository

interface LessonFileRepository: CoroutineCrudRepository<LessonFilesEntity, String> {
    suspend fun deleteByLessonId(lessonId: String)
    suspend fun findByLessonId(lessonId: String): LessonFilesEntity?
}