package com.dev.course.feature.authorization.domain.errors

class FirebaseAuthException(message: String): RuntimeException(message)