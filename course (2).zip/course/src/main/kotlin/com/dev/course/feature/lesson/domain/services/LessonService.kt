package com.dev.course.feature.lesson.domain.services

import com.dev.course.core.extension.toEntity
import com.dev.course.core.extension.toModel
import com.dev.course.feature.files.data.FileEntity
import com.dev.course.feature.files.data.LessonFilesEntity
import com.dev.course.feature.lesson.data.LessonEntity
import com.dev.course.feature.lesson.data.UserLessonEntity
import com.dev.course.feature.lesson.domain.errors.LessonNotFoundException
import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.modules.domain.errors.ModuleNotFoundException
import com.dev.course.feature.repositories.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.flow.toSet
import kotlinx.coroutines.reactive.asFlow
import kotlinx.coroutines.reactor.asFlux
import kotlinx.coroutines.reactor.mono
import kotlinx.coroutines.withContext
import org.springframework.data.domain.PageRequest
import org.springframework.stereotype.Service
import org.springframework.transaction.ReactiveTransactionManager
import org.springframework.transaction.reactive.TransactionalOperator
import kotlin.math.ceil

interface LessonService {
    suspend fun createLesson(lesson: LessonEntity, file: FileEntity?): String
    suspend fun getAllLessons(moduleId: String, page: Int, size: Int): Map<String, Any>
    suspend fun getLesson(id: String): Lesson
    suspend fun getAllByModule(moduleId: String): Collection<Lesson>
    suspend fun getAllByIds(ids: Collection<String>): Collection<Lesson>
    suspend fun deleteLesson(id: String)
    suspend fun getAllLessonsByUser(userId: String, moduleLessons: Collection<Lesson>): Set<Lesson>
    suspend fun updateWatchedLessons(userLessonEntity: UserLessonEntity)
}

@Service
internal class LessonServiceImpl(
        private val transactionManager: ReactiveTransactionManager,
        private val lessonRepository: LessonRepository,
        private val moduleRepository: ModuleRepository,
        private val moduleLessonRepository: ModuleLessonRepository,
        private val lessonFileRepository: LessonFileRepository,
        private val fileRepository: FileRepository,
        private val userLessonsRepositroy: UserLessonsRepositroy
): LessonService {
    override suspend fun createLesson(lesson: LessonEntity, file: FileEntity?): String {
        val operator = TransactionalOperator.create(transactionManager)

        lessonRepository.saveAll(listOf(lesson)).asFlux()
                .thenMany(
                        mono {
                            if (file != null) {
                                lessonFileRepository.save(LessonFilesEntity("${lesson.id}-${file.id}", file.id, lesson.id, null, lesson.createdAt, lesson.updatedAt
                                ))
                            }
                        }
                ).`as`(operator::transactional).asFlow().collect {}
        return lesson.id
    }

    override suspend fun getAllLessons(moduleId: String, page: Int, size: Int): Map<String, Any> {
        val moduleEntity = moduleRepository.findById(moduleId) ?: throw ModuleNotFoundException()
        val pageable = PageRequest.of(page, size)//.descending()
        val lessons = moduleLessonRepository.findAllByModuleId(moduleEntity.id, pageable)?.run {
            lessonRepository.findAllById(map { it.lessonId }).map { it.toModel(getFiles(it.id)) } }?.toSet() ?: emptySet()
        val totalElements = withContext(Dispatchers.IO) {
            moduleLessonRepository.countModuleLessons(moduleEntity.id).block()
        } ?: 0
        val totalPages = ceil(totalElements.toDouble() / size).toInt()
        return mapOf(
                "content" to lessons,
                "totalPages" to totalPages,
                "totalElements" to totalElements,
                "currentPage" to page + 1
        )
    }

    override suspend fun getLesson(id: String): Lesson = lessonRepository.findById(id)?.run { toModel(getFiles(id )) } ?: throw LessonNotFoundException()
    override suspend fun getAllByModule(moduleId: String): Collection<Lesson> {
        TODO("Not yet implemented")
    }

    override suspend fun getAllByIds(ids: Collection<String>): Collection<Lesson> = lessonRepository.findAllById(ids).map { it.toModel(getFiles(it.id)) }.toSet()

    override suspend fun deleteLesson(id: String) {
        val entity =  lessonRepository.findById(id) ?: throw LessonNotFoundException()
        lessonRepository.deleteById(entity.id)
    }

    override suspend fun getAllLessonsByUser(userId: String, moduleLessons: Collection<Lesson>): Set<Lesson> {
        val lessonIds = moduleLessons.map { it.id }
        val lessonsByUser = userLessonsRepositroy.findAllByUserIdAndLessonIdIn(userId, lessonIds)?.toList() ?: emptyList()

        return if (lessonsByUser.isNotEmpty()) {
            moduleLessons.map { lesson ->
                lesson.updateWatched(lessonsByUser.first { it.lessonId == lesson.id }.watched)
                lesson
            }.toSet()
        } else moduleLessons.toSet()

    }

    override suspend fun updateWatchedLessons(userLessonEntity: UserLessonEntity) {
        userLessonsRepositroy.save(userLessonEntity)
    }

    private suspend fun getFiles(lessonId: String) =
            withContext(Dispatchers.IO) {
                lessonFileRepository.findByLessonId(lessonId)?.let {
                    fileRepository.findById(it.fileId)
                }
            }

}

