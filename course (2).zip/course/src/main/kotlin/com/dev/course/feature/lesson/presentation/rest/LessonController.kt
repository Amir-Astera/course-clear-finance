package com.dev.course.feature.lesson.presentation.rest

import com.dev.course.core.config.api.Controller
import com.dev.course.core.config.api.CreateApiResponses
import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.lesson.domain.usecases.*
import com.dev.course.feature.lesson.presentation.dto.CreateLessonDto
import com.dev.course.feature.lesson.presentation.dto.UpdateLessonDto
import com.dev.course.feature.lesson.presentation.dto.UpdateWatchedDto
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag
import org.slf4j.Logger
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.http.codec.multipart.FilePart
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException


@RestController
@RequestMapping("/api/lessons")
@Tag(name = "lessons", description = "The Lesson API")
class LessonController(
        logger: Logger,
        private val createLessonUseCase: CreateLessonUseCase,
        private val deleteLessonUseCase: DeleteLessonUseCase,
        private val getAllLessonsUseCase: GetAllLessonsUseCase,
        private val getLessonUseCase: GetLessonUseCase,
        private val updateLessonUseCase: UpdateLessonUseCase,
        private val getAllLessonsByUserUseCase: GetAllLessonsByUserUseCase,
        private val updateWatchedLesson: UpdateWatchedLesson
): Controller(logger) {

    @SecurityRequirement(name = "security_auth")
    @CreateApiResponses
    @PostMapping
    suspend fun create(
            @RequestBody data: CreateLessonDto,
    ): ResponseEntity<String> {
        try {
            return HttpStatus.CREATED.response(createLessonUseCase(data))
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @DeleteMapping("/{id}")
    suspend fun delete(
            @PathVariable id: String
    ): ResponseEntity<Void> {
        try {
            deleteLessonUseCase(id)
            return HttpStatus.OK.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @GetMapping("/lessons/{id}")
    suspend fun getAll(
            @PathVariable id: String,
            @RequestParam(required = false, defaultValue = "0")
            page: Int,
            @RequestParam(required = false, defaultValue = "10")
            size: Int,
    ): ResponseEntity<Map<String, Any>> {
        try {
            return HttpStatus.OK.response(getAllLessonsUseCase(id, page, size))
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @GetMapping("/{id}")
    suspend fun get(
            @PathVariable id: String
    ): ResponseEntity<Lesson> {
        try {
            return HttpStatus.OK.response(getLessonUseCase(id))
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @PutMapping
    suspend fun update(
            @RequestBody data: UpdateLessonDto
    ): ResponseEntity<Void> {
        try {
            updateLessonUseCase(data)
            return HttpStatus.OK.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @GetMapping("/lessons/user/{userId}/module/{moduleId}")
    suspend fun getAllByUser(
            @PathVariable userId: String,
            @PathVariable moduleId: String
    ): ResponseEntity<Set<Lesson>> {
        try {
            return HttpStatus.OK.response(getAllLessonsByUserUseCase(userId, moduleId))
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @PutMapping("/watched")
    suspend fun updateWatched(
            @RequestBody data: UpdateWatchedDto
    ): ResponseEntity<Void> {
        try {
            updateWatchedLesson(data.userId, data.lessonId, data.watched)
            return HttpStatus.OK.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }
}