package com.dev.course.feature.lesson.domain.models

import com.dev.course.feature.files.data.FileEntity
import java.time.LocalDateTime
import java.util.*

class Lesson(
        val id: String = UUID.randomUUID().toString(),
        val name: String,
        val url: String,
        watched: Boolean = false,
        val number: Int,
        val homework: FileEntity? = null,
        val version: Long? = null,
        val createdAt: LocalDateTime? = null,
        var updatedAt: LocalDateTime = LocalDateTime.now()
) {
    var watched = watched
        private set

    fun updateWatched(watched: Boolean?) {
        this.watched = watched ?: this.watched
    }
}