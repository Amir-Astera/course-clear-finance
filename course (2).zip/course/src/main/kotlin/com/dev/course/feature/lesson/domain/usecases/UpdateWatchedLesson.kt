package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.feature.lesson.data.UserLessonEntity
import com.dev.course.feature.lesson.domain.services.LessonService
import com.dev.course.feature.users.domain.services.UserAggregateService
import org.springframework.stereotype.Service

interface UpdateWatchedLesson {
    suspend operator fun invoke(userId: String, lessonId: String, watched: Boolean)
}

@Service
internal class UpdateWatchedLessonImpl(
        private val lessonService: LessonService,
        private val userAggregateService: UserAggregateService
): UpdateWatchedLesson {
    override suspend fun invoke(userId: String, lessonId: String, watched: Boolean) {
        val user = userAggregateService.get(userId)
        val lesson = lessonService.getLesson(lessonId)
        lessonService.updateWatchedLessons(UserLessonEntity(userId = user.id, lessonId = lesson.id, watched = watched, version = null))
    }

}