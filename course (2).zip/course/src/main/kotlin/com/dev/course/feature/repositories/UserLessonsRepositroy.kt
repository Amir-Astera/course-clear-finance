package com.dev.course.feature.repositories

import com.dev.course.feature.lesson.data.UserLessonEntity
import kotlinx.coroutines.flow.Flow
import org.springframework.data.repository.kotlin.CoroutineCrudRepository
import org.springframework.stereotype.Repository
import reactor.core.publisher.Flux

@Repository
interface UserLessonsRepositroy: CoroutineCrudRepository<UserLessonEntity, String> {
    fun findAllByUserIdAndLessonIdIn(userId: String, lessonId: Collection<String>): Flow<UserLessonEntity>?
}