package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.core.extension.toEntity
import com.dev.course.feature.lesson.domain.services.LessonService
import com.dev.course.feature.lesson.presentation.dto.UpdateLessonDto
import com.dev.course.feature.repositories.FileRepository
import org.springframework.stereotype.Service

interface UpdateLessonUseCase {
    suspend operator fun invoke(dto: UpdateLessonDto): String
}

@Service
internal class UpdateLessonUseCaseImpl(
        private val lessonService: LessonService,
        private val fileRepository: FileRepository
): UpdateLessonUseCase {
    override suspend fun invoke(dto: UpdateLessonDto): String {
        val oldEntity = lessonService.getLesson(dto.id).toEntity()
        val fileEntity = if (dto.fileId != null) fileRepository.findById(dto.fileId) else null
        val newEntity = oldEntity.copy(
                url = dto.url ?: oldEntity.url,
                name = dto.name ?: oldEntity.name,
                number = dto.number ?: oldEntity.number,
                watched = dto.watched ?: oldEntity.watched,
        )
        return lessonService.createLesson(newEntity, fileEntity)
    }

}