package com.dev.course.feature.users.presentation.dto

data class AddAuthoritiesToUserDto(
    val authorityIds: List<String>
)