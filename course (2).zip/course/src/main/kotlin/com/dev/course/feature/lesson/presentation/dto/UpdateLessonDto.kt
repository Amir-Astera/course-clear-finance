package com.dev.course.feature.lesson.presentation.dto

data class UpdateLessonDto(
        val id: String,
        val url: String?,
        val name: String?,
        val number: Int?,
        val watched: Boolean?,
        val fileId: String?
)
