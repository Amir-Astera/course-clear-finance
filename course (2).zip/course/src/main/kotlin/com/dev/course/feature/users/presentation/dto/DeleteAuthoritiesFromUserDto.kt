package com.dev.course.feature.users.presentation.dto


data class DeleteAuthoritiesFromUserDto (
    val authorityIds: List<String>
)