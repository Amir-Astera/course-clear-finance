package com.dev.course.feature.repositories

import com.dev.course.feature.lesson.data.LessonEntity
import org.springframework.data.repository.kotlin.CoroutineCrudRepository

interface LessonRepository: CoroutineCrudRepository<LessonEntity, String> {
}