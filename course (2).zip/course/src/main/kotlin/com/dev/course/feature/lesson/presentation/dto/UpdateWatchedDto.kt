package com.dev.course.feature.lesson.presentation.dto

data class UpdateWatchedDto(
        val userId: String,
        val lessonId: String,
        val watched: Boolean,
)
