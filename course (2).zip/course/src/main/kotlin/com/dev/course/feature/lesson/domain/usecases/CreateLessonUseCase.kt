package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.core.extension.toEntity
import com.dev.course.feature.files.domain.services.FileService
import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.lesson.domain.services.LessonService
import com.dev.course.feature.lesson.presentation.dto.CreateLessonDto
import com.dev.course.feature.repositories.FileRepository
import org.springframework.stereotype.Service
import java.io.FileNotFoundException

interface CreateLessonUseCase {
    suspend operator fun invoke(data: CreateLessonDto): String
}

@Service
internal class CreateLessonUseCaseImpl(
        private val lessonService: LessonService,
        private val fileRepository: FileRepository
): CreateLessonUseCase {
    override suspend fun invoke(data: CreateLessonDto): String {
        val fileEntity = if (data.fileId != null) fileRepository.findById(data.fileId) else null
        return lessonService.createLesson(Lesson(
                name = data.name,
                url = data.url,
                number = data.number,
                watched = data.number == 1
        ).toEntity(), fileEntity)
    }

}