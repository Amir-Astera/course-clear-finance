package com.dev.course.feature.lesson.domain.errors

class LessonNotFoundException : RuntimeException("Lesson not found!")