package com.dev.course.core.extension

import com.dev.course.feature.authority.data.entity.AuthorityEntity
import com.dev.course.feature.authority.domain.models.Authority
import com.dev.course.feature.files.data.FileEntity
import com.dev.course.feature.files.domain.models.File
import com.dev.course.feature.lesson.data.LessonEntity
import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.modules.data.ModuleEntity
import com.dev.course.feature.modules.domain.models.Module
import com.dev.course.feature.users.data.entity.UserEntity
import com.dev.course.feature.users.domain.models.UserAggregate
import java.time.LocalDateTime

fun UserEntity.toModel(
        authorities: Collection<Authority>,

): UserAggregate {
    return UserAggregate(
            id = id,
            name = name,
            surname = surname,
            email = email,
            phone = phone,
            login = login,
            authorities = authorities,
            logoUrl = logo,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}

fun AuthorityEntity.toModel(
        version: Long? = null,
        createdAt: LocalDateTime? = null
): Authority {
    return Authority(
            id = id,
            name = name,
            description = description,
            version = version ?: this.version,
            createdAt = createdAt ?: this.createdAt,
            updatedAt = updatedAt
    )
}

fun Authority.toEntity(): AuthorityEntity {
    return AuthorityEntity(
            id = id,
            name = name,
            description = description,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}

fun UserAggregate.toEntity(): UserEntity {
    return UserEntity(
            id = id,
            name = name,
            surname = surname,
            email = email,
            phone = phone,
            login = login,
            logo = logoUrl,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}

fun FileEntity.toModel(): File {
    return File(
            id = id,
            directory = directory,
            format = format,
            url = url
    )
}

fun File.toEntity(): FileEntity {
    return FileEntity(
            id = id,
            directory = directory,
            format = format,
            url = url,
            version = version,
            createdAt = LocalDateTime.now()
    )
}

fun LessonEntity.toModel(
        file: FileEntity? = null
): Lesson {
    return Lesson(
            id = id,
            name = name,
            url = url,
            number = number,
            watched = watched,
            homework = file,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}

fun Lesson.toEntity(): LessonEntity {
    return LessonEntity(
            id = id,
            name = name,
            url = url,
            watched = watched,
            number = number,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}

fun ModuleEntity.toModel(
        lessons: Collection<LessonEntity>? = null,
        file: FileEntity
): Module {
    return Module(
            id = id,
            name = name,
            logo = file,
            number = number,
            lessons = lessons?.toSet(),
            status = status,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}

fun Module.toEntity(): ModuleEntity {
    return ModuleEntity(
            id = id,
            name = name,
            number = number,
            status = status,
            version = version,
            createdAt = createdAt,
            updatedAt = updatedAt
    )
}