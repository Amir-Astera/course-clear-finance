package com.dev.course.feature.modules.presentation.dto

import com.dev.course.feature.files.presentation.dto.CreateFileDto

data class CreateModuleDto(
        val name: String,
        val fileId: String,
        val number: Int,
        val status: Boolean
)
