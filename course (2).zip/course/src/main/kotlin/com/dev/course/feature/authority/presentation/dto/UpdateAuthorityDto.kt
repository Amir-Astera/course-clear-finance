package com.dev.course.feature.authority.presentation.dto

data class UpdateAuthorityDto (
    val name: String,
    val description: String
)