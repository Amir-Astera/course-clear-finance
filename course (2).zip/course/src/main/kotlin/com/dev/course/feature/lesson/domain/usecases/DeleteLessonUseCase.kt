package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.feature.lesson.domain.services.LessonService
import org.springframework.stereotype.Service

interface DeleteLessonUseCase {
    suspend operator fun invoke(id: String)
}

@Service
internal class DeleteLessonUseCaseImpl (
        private val lessonService: LessonService
): DeleteLessonUseCase {
    override suspend fun invoke(id: String) {
        return lessonService.deleteLesson(id)
    }
}