package com.dev.course.feature.lesson.data

import com.dev.course.feature.files.data.FileEntity
import com.dev.course.feature.lesson.presentation.dto.UpdateLessonDto
import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Version
import org.springframework.data.relational.core.mapping.Table
import java.time.LocalDateTime
import java.util.UUID

@Table(name = "lessons")
data class LessonEntity(
        @Id
        val id: String,
        val name: String,
        val url: String,
        val watched: Boolean = false,
        val number: Int,
        @Version
        var version: Long? = null,
        val createdAt: LocalDateTime? = null,
        val updatedAt: LocalDateTime
)