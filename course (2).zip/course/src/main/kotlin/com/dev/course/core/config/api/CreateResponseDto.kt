package com.dev.course.core.config.api

data class CreateResponseDto(val id: String)