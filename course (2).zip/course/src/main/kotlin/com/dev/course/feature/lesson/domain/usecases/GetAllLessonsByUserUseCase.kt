package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.lesson.domain.services.LessonService
import com.dev.course.feature.users.domain.services.UserAggregateService
import org.springframework.stereotype.Service

interface GetAllLessonsByUserUseCase {
    suspend operator fun invoke(userId: String, moduleId: String): Set<Lesson>
}

@Service
internal class GetAllLessonsByUserUseCaseImpl(
        private val lessonsService: LessonService,
        private val userAggregateService: UserAggregateService,
): GetAllLessonsByUserUseCase {
    override suspend fun invoke(userId: String, moduleId: String): Set<Lesson> {
        val user = userAggregateService.get(userId)
        val lessonsByModule = lessonsService.getAllByModule(moduleId)
        return lessonsService.getAllLessonsByUser(user.id, lessonsByModule)
    }

}