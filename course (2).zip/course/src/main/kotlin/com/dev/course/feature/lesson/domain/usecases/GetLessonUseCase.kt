package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.lesson.domain.services.LessonService
import org.springframework.stereotype.Service

interface GetLessonUseCase {
    suspend operator fun invoke(id: String): Lesson
}

@Service
internal class GerLessonUseCaseImpl(
        private val lessonService: LessonService
): GetLessonUseCase {
    override suspend fun invoke(id: String): Lesson {
        return lessonService.getLesson(id)
    }

}