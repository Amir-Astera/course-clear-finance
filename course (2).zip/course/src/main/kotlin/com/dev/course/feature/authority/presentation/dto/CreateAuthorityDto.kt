package com.dev.course.feature.authority.presentation.dto

data class CreateAuthorityDto (
    val name: String,
    val description: String
)
