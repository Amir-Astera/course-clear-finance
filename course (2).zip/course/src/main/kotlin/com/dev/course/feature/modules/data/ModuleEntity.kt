package com.dev.course.feature.modules.data

import com.dev.course.feature.files.data.FileEntity
import com.dev.course.feature.lesson.data.LessonEntity
import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Version
import org.springframework.data.relational.core.mapping.Table
import java.time.LocalDateTime
import java.util.UUID

@Table(name = "modules")
class ModuleEntity(
        @Id
        val id: String,
        val name: String,
        val number: Int,
        val status: Boolean = false,
        @Version
        var version: Long?,
        val createdAt: LocalDateTime? = null,
        val updatedAt: LocalDateTime
)