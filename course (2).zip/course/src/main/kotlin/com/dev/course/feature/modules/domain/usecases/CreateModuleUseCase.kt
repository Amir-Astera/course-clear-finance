package com.dev.course.feature.modules.domain.usecases

import com.dev.course.core.extension.toEntity
import com.dev.course.feature.files.domain.services.FileService
import com.dev.course.feature.modules.domain.models.Module
import com.dev.course.feature.modules.domain.services.ModuleService
import com.dev.course.feature.modules.presentation.dto.CreateModuleDto
import com.dev.course.feature.repositories.FileRepository
import org.springframework.stereotype.Service
import java.io.FileNotFoundException

interface CreateModuleUseCase {
    suspend operator fun invoke(dto: CreateModuleDto)
}

@Service
internal class CreateModuleUseCaseImpl(
        private val moduleService: ModuleService,
        private val fileRepository: FileRepository
): CreateModuleUseCase {
    override suspend fun invoke(dto: CreateModuleDto) {
        val fileEntity = fileRepository.findById(dto.fileId) ?: throw FileNotFoundException()
        val module = Module(
                name = dto.name,
                logo = fileEntity,
                number = dto.number,
                status = dto.status
        )
        moduleService.createModule(module)
    }
}