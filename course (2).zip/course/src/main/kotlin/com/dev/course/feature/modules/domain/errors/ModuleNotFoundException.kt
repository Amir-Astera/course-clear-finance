package com.dev.course.feature.modules.domain.errors

class ModuleNotFoundException : RuntimeException("Module not found. Not enough permissions to execute.")