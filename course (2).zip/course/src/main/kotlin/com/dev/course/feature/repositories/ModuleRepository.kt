package com.dev.course.feature.repositories

import com.dev.course.feature.modules.data.ModuleEntity
import kotlinx.coroutines.flow.Flow
import org.springframework.data.domain.Pageable
import org.springframework.data.r2dbc.repository.Query
import org.springframework.data.repository.kotlin.CoroutineCrudRepository
import org.springframework.stereotype.Repository
import reactor.core.publisher.Mono

@Repository
interface ModuleRepository: CoroutineCrudRepository<ModuleEntity, String> {
    @Query("SELECT * FROM modules ORDER BY number LIMIT :limit OFFSET :offset")
    fun findUsersWithPagination(limit: Int, offset: Int): Flow<ModuleEntity>

//    @Query("SELECT COUNT(*) FROM users")
//    override suspend fun count(): Long

    @Query("SELECT COUNT(*) FROM modules")
    fun countModules(): Mono<Long>
}