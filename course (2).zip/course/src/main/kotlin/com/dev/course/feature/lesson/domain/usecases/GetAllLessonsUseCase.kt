package com.dev.course.feature.lesson.domain.usecases

import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.lesson.domain.services.LessonService
import org.springframework.stereotype.Service

interface GetAllLessonsUseCase {
    suspend operator fun invoke(moduleId: String, page: Int, size: Int): Map<String, Any>
}

@Service
internal class GetAllLessonsUseCaseImpl(
        private val lessonService: LessonService
): GetAllLessonsUseCase {
    override suspend fun invoke(moduleId: String, page: Int, size: Int): Map<String, Any> {
        return lessonService.getAllLessons(moduleId, page, size)
    }

}