package com.dev.course.feature.authority.domain.errors

class AuthorityDuplicateNameException : RuntimeException("Duplicate name. Please try different one.")