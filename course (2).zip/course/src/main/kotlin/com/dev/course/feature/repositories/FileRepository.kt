package com.dev.course.feature.repositories

import com.dev.course.feature.files.data.FileEntity
import org.springframework.data.repository.kotlin.CoroutineCrudRepository
import org.springframework.stereotype.Repository

@Repository
interface FileRepository: CoroutineCrudRepository<FileEntity, String> {
}