package com.dev.course.feature.repositories

import com.dev.course.feature.lesson.data.ModuleLessonEntity
import kotlinx.coroutines.flow.Flow
import org.springframework.data.domain.Pageable
import org.springframework.data.r2dbc.repository.Query
import org.springframework.data.repository.kotlin.CoroutineCrudRepository
import org.springframework.stereotype.Repository
import reactor.core.publisher.Mono

@Repository
interface ModuleLessonRepository: CoroutineCrudRepository<ModuleLessonEntity, String> {
    fun findAllByModuleId(moduleId: String, pageable: Pageable): Flow<ModuleLessonEntity>?
    fun findAllByModuleId(moduleId: String): Flow<ModuleLessonEntity>?
//    fun findAll(offset: Int, limit: Int, pageable: Pageable): Flow<ModuleLessonEntity>
    fun findAllBy(pageable: Pageable): Flow<ModuleLessonEntity>

    @Query("SELECT COUNT(*) FROM module_lessons where module_id = :id")
    fun countModuleLessons(id: String): Mono<Long>
}