package com.dev.course.feature.lesson.data

import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Version
import org.springframework.data.relational.core.mapping.Table
import java.time.LocalDateTime

@Table(name = "module_lessons")
data class ModuleLessonEntity(
        @Id
        val id: String,
        val moduleId: String,
        val lessonId: String,
        @Version
        val version: Long?,
        val createdAt: LocalDateTime? = null,
        val updatedAt: LocalDateTime
)
