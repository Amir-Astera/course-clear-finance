package com.dev.course.feature.users.domain.errors

class UserPartnersNotFoundException: RuntimeException("User's partners not found ")