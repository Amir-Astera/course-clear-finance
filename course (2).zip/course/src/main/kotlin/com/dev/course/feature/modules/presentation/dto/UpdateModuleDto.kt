package com.dev.course.feature.modules.presentation.dto

import com.dev.course.feature.files.data.FileEntity
import com.dev.course.feature.files.presentation.dto.CreateFileDto

data class UpdateModuleDto(
        val id: String,
        val name: String?,
        val fileId: String?,
        val number: Int?,
        val status: Boolean?
)

