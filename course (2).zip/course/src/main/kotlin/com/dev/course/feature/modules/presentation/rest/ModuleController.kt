package com.dev.course.feature.modules.presentation.rest

import com.dev.course.core.config.api.Controller
import com.dev.course.core.config.api.CreateApiResponses
import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.lesson.presentation.dto.UpdateLessonDto
import com.dev.course.feature.modules.domain.models.Module
import com.dev.course.feature.modules.domain.usecases.*
import com.dev.course.feature.modules.presentation.dto.CreateModuleDto
import com.dev.course.feature.modules.presentation.dto.UpdateModuleDto
import com.dev.course.feature.modules.presentation.dto.UpdateModuleWithLessonDto
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag
import org.slf4j.Logger
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException

@RestController
@RequestMapping("/api/modules")
@Tag(name = "modules", description = "The Module API")
class ModuleController(
        logger: Logger,
        private val createModuleUseCase: CreateModuleUseCase,
        private val deleteModuleUseCase: DeleteModuleUseCase,
        private val getAllModulesUseCase: GetAllModulesUseCase,
        private val getModuleUseCase: GetModuleUseCase,
        private val updateModuleUseCase: UpdateModuleUseCase,
        private val updateModuleWithLessonsUseCase: UpdateModuleWithLessonsUseCase
): Controller(logger) {
    @SecurityRequirement(name = "security_auth")
    @CreateApiResponses
    @PostMapping
    suspend fun create(
            @RequestBody data: CreateModuleDto
    ): ResponseEntity<Void> {
        try {
            createModuleUseCase(data)
            return HttpStatus.CREATED.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @DeleteMapping("/{id}")
    suspend fun delete(
            @PathVariable id: String
    ): ResponseEntity<Void> {
        try {
            deleteModuleUseCase(id)
            return HttpStatus.OK.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @GetMapping("/lessons")
    suspend fun getAll(
            @RequestParam(required = false, defaultValue = "0")
            page: Int,
            @RequestParam(required = false, defaultValue = "10")
            size: Int,
    ): ResponseEntity<Map<String, Any>> {
        try {
            return HttpStatus.OK.response(getAllModulesUseCase(page, size))
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @GetMapping("/{id}")
    suspend fun get(
            @PathVariable id: String
    ): ResponseEntity<Module> {
        try {
            return HttpStatus.OK.response(getModuleUseCase(id))
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @PutMapping("/module-lessons")
    suspend fun updateWithLesson(
            @RequestBody data: UpdateModuleWithLessonDto
    ): ResponseEntity<Void> {
        try {
            updateModuleWithLessonsUseCase(data)
            return HttpStatus.OK.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }

    @SecurityRequirement(name = "security_auth")
    @PutMapping
    suspend fun update(
            @RequestBody data: UpdateModuleDto
    ): ResponseEntity<Void> {
        try {
            updateModuleUseCase(data)
            return HttpStatus.OK.response()
        } catch (ex: Exception) {
            val (code, message) = getError(ex)
            throw ResponseStatusException(code, message)
        }
    }
}