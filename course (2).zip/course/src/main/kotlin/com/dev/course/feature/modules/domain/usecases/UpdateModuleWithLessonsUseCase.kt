package com.dev.course.feature.modules.domain.usecases

import com.dev.course.core.extension.toEntity
import com.dev.course.feature.lesson.domain.errors.LessonNotFoundException
import com.dev.course.feature.lesson.domain.services.LessonService
import com.dev.course.feature.modules.domain.services.ModuleService
import com.dev.course.feature.modules.presentation.dto.UpdateModuleDto
import com.dev.course.feature.modules.presentation.dto.UpdateModuleWithLessonDto
import org.springframework.stereotype.Service

interface UpdateModuleWithLessonsUseCase {
    suspend operator fun invoke(dto: UpdateModuleWithLessonDto)
}

@Service
internal class UpdateModuleWithLessonsUseCaseImpl(
        private val moduleService: ModuleService,
        private val lessonService: LessonService
): UpdateModuleWithLessonsUseCase {
    override suspend fun invoke(dto: UpdateModuleWithLessonDto) {
        val lessonsEntity = lessonService.getAllByIds(dto.lessons).run { map { it.toEntity() } }.toSet()
        if (lessonsEntity.isEmpty()) throw LessonNotFoundException()

        val oldEntity = moduleService.get(dto.id)
        val newEntity = oldEntity.copy(
                lessons = lessonsEntity,
        )
        moduleService.updateWithLesson(newEntity)
    }

}