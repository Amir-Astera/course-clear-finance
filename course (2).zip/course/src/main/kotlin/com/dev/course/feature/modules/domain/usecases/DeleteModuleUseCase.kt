package com.dev.course.feature.modules.domain.usecases

import com.dev.course.feature.modules.domain.services.ModuleService
import org.springframework.stereotype.Service

interface DeleteModuleUseCase {
    suspend operator fun invoke(id: String)
}

@Service
internal class DeleteModuleUseCaseImpl(
        private val moduleService: ModuleService
): DeleteModuleUseCase {
    override suspend fun invoke(id: String) {
        moduleService.deleteModule(id)
    }
}