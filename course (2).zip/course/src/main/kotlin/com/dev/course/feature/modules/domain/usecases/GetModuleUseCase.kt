package com.dev.course.feature.modules.domain.usecases

import com.dev.course.feature.modules.domain.models.Module
import com.dev.course.feature.modules.domain.services.ModuleService
import org.springframework.stereotype.Service

interface GetModuleUseCase {
    suspend operator fun invoke(id: String): Module
}

@Service
internal class GetModelUseCaseImpl(
        private val moduleService: ModuleService
): GetModuleUseCase {
    override suspend fun invoke(id: String): Module {
        return moduleService.get(id)
    }

}