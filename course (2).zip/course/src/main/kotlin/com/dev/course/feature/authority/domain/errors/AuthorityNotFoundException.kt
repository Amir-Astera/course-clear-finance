package com.dev.course.feature.authority.domain.errors

class AuthorityNotFoundException: RuntimeException ("Authority not found. Please try different one.")