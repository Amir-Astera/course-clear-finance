package com.dev.course.feature.modules.domain.services

import com.dev.course.core.extension.toEntity
import com.dev.course.core.extension.toModel
import com.dev.course.feature.files.data.ModuleFilesEntity
import com.dev.course.feature.lesson.data.ModuleLessonEntity
import com.dev.course.feature.modules.domain.errors.ModuleNotFoundException
import com.dev.course.feature.modules.domain.models.Module
import com.dev.course.feature.repositories.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.flow.toSet
import kotlinx.coroutines.reactive.asFlow
import kotlinx.coroutines.reactor.asFlux
import kotlinx.coroutines.withContext
import org.springframework.stereotype.Service
import org.springframework.transaction.ReactiveTransactionManager
import org.springframework.transaction.reactive.TransactionalOperator
import java.io.FileNotFoundException
import kotlin.math.ceil

interface ModuleService {
    suspend fun createModule(module: Module)
    suspend fun deleteModule(id: String)
    suspend fun getAll(page: Int, size: Int): Map<String, Any>
    suspend fun get(id: String): Module
    suspend fun updateWithLesson(module: Module)
}

@Service
internal class ModuleServiceImpl(
        private val transactionManager: ReactiveTransactionManager,
        private val moduleRepository: ModuleRepository,
        private val moduleLessonRepository: ModuleLessonRepository,
        private val moduleFileRepository: ModuleFileRepository,
        private val fileRepository: FileRepository,
        private val lessonRepository: LessonRepository
): ModuleService {
    override suspend fun createModule(module: Module) {
        val operator = TransactionalOperator.create(transactionManager)
        moduleRepository.saveAll(listOf(module.toEntity())).asFlux()
                .thenMany(
                        moduleFileRepository.saveAll(listOf(
                                ModuleFilesEntity("${module.id}-${module.logo.id}", module.logo.id, module.id, module.version, module.createdAt, module.updatedAt
                                ))).asFlux()
                ).`as`(operator::transactional).asFlow().collect {}
    }

    override suspend fun deleteModule(id: String) {
        val entity = moduleRepository.findById(id) ?: throw ModuleNotFoundException()
        moduleRepository.deleteById(entity.id)
    }

    override suspend fun getAll(page: Int, size: Int): Map<String, Any> {
        val offset = page * size
        val modules = moduleRepository.findUsersWithPagination(size, offset).map { it.toModel(getLessons(it.id), getFiles(it.id)) }.toSet()
        val totalElements = withContext(Dispatchers.IO) {
            moduleRepository.countModules().block()
        } ?: 0
        val totalPages = ceil(totalElements.toDouble() / size).toInt()
        return mapOf(
            "content" to modules,
            "totalPages" to totalPages,
            "totalElements" to totalElements,
            "currentPage" to page + 1
        )

    }

    override suspend fun get(id: String): Module {
        return moduleRepository.findById(id)?.run { toModel(getLessons(id), getFiles(id)) } ?: throw ModuleNotFoundException()
    }

    override suspend fun updateWithLesson(module: Module) {
        val operator = TransactionalOperator.create(transactionManager)
        moduleRepository.saveAll(listOf(module.toEntity())).asFlux()
                .thenMany(
                        moduleLessonRepository.saveAll(module.lessons!!.map {
                            val id = "${module.id}-${it.id}"
                            ModuleLessonEntity(id, module.id, it.id, null, it.createdAt, it.updatedAt)
                        }).asFlux()
                ).`as`(operator::transactional).asFlow().collect {}
    }

    private suspend fun getFiles(moduleId: String) =
        withContext(Dispatchers.IO) {
            moduleFileRepository.findByModuleId(moduleId).let {
                fileRepository.findById(it.fileId) ?: throw FileNotFoundException()
            }
        }

    private suspend fun getLessons(moduleId: String) =
            withContext(Dispatchers.IO) {
                 moduleLessonRepository.findAllByModuleId(moduleId)
                         ?.run {
                             lessonRepository.findAllById(map { it.lessonId })
                         }
            }?.toList()
}
