package com.dev.course.feature.lesson.data

import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Version
import org.springframework.data.relational.core.mapping.Table
import java.time.LocalDateTime
import java.util.UUID

@Table(name = "user_lesson")
data class UserLessonEntity (
    @Id
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val lessonId: String,
    val watched: Boolean,
    @Version
    val version: Long?,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val updatedAt: LocalDateTime = LocalDateTime.now()
)