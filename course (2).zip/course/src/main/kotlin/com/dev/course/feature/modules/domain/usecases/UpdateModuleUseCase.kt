package com.dev.course.feature.modules.domain.usecases

import com.dev.course.core.extension.toEntity
import com.dev.course.feature.files.domain.services.FileService
import com.dev.course.feature.lesson.domain.services.LessonService
import com.dev.course.feature.modules.domain.services.ModuleService
import com.dev.course.feature.modules.presentation.dto.UpdateModuleDto
import com.dev.course.feature.repositories.FileRepository
import org.springframework.stereotype.Service

interface UpdateModuleUseCase {
    suspend operator fun invoke(dto: UpdateModuleDto)
}

@Service
internal class UpdateModuleUseCaseImpl(
        private val moduleService: ModuleService,
        private val fileService: FileService,
        private val lessonService: LessonService,
        private val fileRepository: FileRepository
): UpdateModuleUseCase {
    override suspend fun invoke(dto: UpdateModuleDto) {
        val oldEntity = moduleService.get(dto.id)

        val fileEntity = if (dto.fileId != null) {
            fileRepository.findById(dto.fileId)
        } else null

        val newEntity = oldEntity.copy(
                name = dto.name ?: oldEntity.name,
                logo = fileEntity ?: oldEntity.logo,
                number = dto.number ?: oldEntity.number,
                status = dto.status ?: oldEntity.status
        )
        moduleService.createModule(newEntity)
    }

}