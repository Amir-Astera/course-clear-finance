package com.dev.course.feature.files.domain.models

enum class FileDirectory{
    LESSON,
    LOGO
}