package com.dev.course.feature.modules.domain.models

import com.dev.course.feature.files.data.FileEntity
import com.dev.course.feature.lesson.data.LessonEntity
import com.dev.course.feature.lesson.domain.errors.LessonNotFoundException
import com.dev.course.feature.lesson.domain.models.Lesson
import com.dev.course.feature.modules.presentation.dto.UpdateModuleDto
import java.time.LocalDateTime
import java.util.*

data class Module(
        val id: String = UUID.randomUUID().toString(),
        val name: String,
        val logo: FileEntity,
        val number: Int,
        val lessons: Set<LessonEntity>? = emptySet(),
        val status: Boolean,
        val version: Long? = null,
        val createdAt: LocalDateTime? = null,
        val updatedAt: LocalDateTime = LocalDateTime.now()
)
//{
//    var name = name
//        private set
//
//    var logo = logo
//        private set
//
//    var number = number
//        private set
//
//    var status = status
//        private set
//
//    var version = version
//        private set
//
//    private var _lessons = lessons.toMutableList()
//    val lessons: Collection<LessonEntity>
//        get() = _lessons
//
//    fun update(dto: UpdateModuleDto) {
//        this.name = dto.name ?: this.name
//        this.number = dto.number ?: this.number
//        this.status = dto.status ?: this.status
//    }
//
//    fun addLesson(lessonId: String): LessonEntity {
//        return _lessons.find { it.id == lessonId } ?: LessonEntity(lessonId).also { _lessons.add(it) }
//    }
//
//    fun deleteLesson(lessonId: String): LessonEntity {
//        return _lessons.find { it.id == lessonId }?.also { _lessons.remove(it) }
//                ?: throw LessonNotFoundException()
//    }
//
//    fun updateLessons(lessonsIds: Collection<String>) {
//        val currentLessons = ArrayList(_lessons)
//
//        currentLessons.forEach { currentLesson ->
//            if (!lessonsIds.contains(currentLesson.id)) {
//                deleteLesson(currentLesson.id)
//            }
//        }
//
//        lessonsIds.forEach { lessonId ->
//            if (currentLessons.isEmpty()) {
//                currentLessons.add()
//            }
//        }
//    }
//}
