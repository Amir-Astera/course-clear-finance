package com.dev.course.feature.lesson.presentation.dto

import com.dev.course.feature.files.domain.models.File

data class CreateLessonDto(
        val name: String,
        val url: String,
        val number: Int,
        val fileId: String?
)
