package com.dev.course.feature.modules.domain.usecases

import com.dev.course.feature.modules.domain.models.Module
import com.dev.course.feature.modules.domain.services.ModuleService
import org.springframework.stereotype.Service

interface GetAllModulesUseCase {
    suspend operator fun invoke(page: Int, size: Int): Map<String, Any>
}

@Service
internal class GetAllModulesUseCaseImpl(
        private val moduleService: ModuleService
): GetAllModulesUseCase {
    override suspend fun invoke(page: Int, size: Int): Map<String, Any> {
        return moduleService.getAll(page, size)
    }
}